# -*- coding: utf-8 -*-
import copy
import logging
import functools
from ground.base import BaseAction

info_logger = logging.getLogger('info_log')


class JsonAction(BaseAction):

    def __init__(self, *args, **kwargs):
        super(JsonAction, self).__init__(*args, **kwargs)
        self.user = {}

    def write_data(self, raw_data):
        ret_dict = copy.deepcopy(raw_data)
        self._response_data_dict['data'] = ret_dict

    def post_processor(self, request):
        msg = '[%(method)s %(path)r][from %(ip)s %(agent)r] get_param:%(get)r, post_param:%(post)r, body:%(body)r.' \
            % {'method': request.method, 'path': request.path,
               'get': '',  # request.GET,
               'post': '',  # request.POST,
               'body': '',  # request.body,
               'agent': request.META.get('HTTP_USER_AGENT'),
               'ip': request.META.get('REMOTE_ADDR'),
               }
        info_logger.info('user visit, %s' % (msg))

    def pre_handler_error(self, e):
        request = self._request  # 基类定义了
        msg = '[%(method)s %(path)r][from %(ip)s %(agent)r] get_param:%(get)r, post_param:%(post)r, body:%(body)r.' \
            % {'method': request.method, 'path': request.path, 'get': request.GET,
               'post': request.POST, 'body': '',
               'agent': request.META.get('HTTP_USER_AGENT'),
               'ip': request.META.get('REMOTE_ADDR'),
               }
        info_logger.info('raise error, %s<%s>: %s' % (e.__class__.__name__, e.msg, msg))


def user_required(func):
    @functools.wraps(func)
    def _(self, request, *args, **kwargs):
        return func(self, request, *args, **kwargs)
    return _
