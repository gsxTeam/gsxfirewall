# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models


class User(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=32, default='')
    email = models.CharField('邮箱', max_length=50, default='')
    mobile = models.CharField('电话', max_length=16, default='')
    gender = models.IntegerField('性别', default=0)
    avatar = models.CharField('头像', max_length=255, default='')
    score = models.IntegerField(default=0)
    desc = models.CharField('简介', max_length=64, default='')

    status = models.IntegerField(default=1)
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    update_time = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 't_user'


class PassAuth(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(db_index=True)
    username = models.CharField('用户名', max_length=32, unique=True)
    password = models.CharField('密码', max_length=64)

    class Meta:
        db_table = 't_password_auth'


class AppAuth(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    appkey = models.CharField(max_length=32, unique=True)
    appsecret = models.CharField(max_length=100)
    scope = models.IntegerField(default=0)
    desc = models.CharField(max_length=50, default='')

    class Meta:
        db_table = 't_app_auth'


class OauthAuth(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(db_index=True)
    oauth_type = models.IntegerField('认证类型', default=1)
    openid = models.CharField('openid', max_length=64)
    thirdid = models.CharField('第三方UID', max_length=32, default='')
    access_token = models.CharField(max_length=64, default='')
    expires = models.IntegerField(default=0)

    class Meta:
        db_table = 't_oauth_auth'
