# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models


class Rule(models.Model):
    id = models.AutoField(primary_key=True)
    hostname = models.CharField('部署单元名', max_length=20)
    dest = models.CharField('目标IP', max_length=100)
    dport = models.CharField('目标端口', max_length=100)
    protocol = models.CharField('协议', max_length=20, default='all',
            choices=[('all', 'all'), ('tcp', 'tcp'), ('udp', 'udp'), ('icmp', 'icmp')])
    action = models.CharField('动作', max_length=20, default='ACCEPT',
            choices=[('ACCEPT', 'ACCEPT'), ('DROP', 'DROP'), ('REJECT', 'REJECT')])

    status = models.IntegerField('状态', default=1,
            choices=[(0, 'delete'), (1, 'ok')])
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    update_time = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 't_rule'
        verbose_name = '规则'
        verbose_name_plural = verbose_name

    def _make_dport(self):
        dport = '-m multiport --dports %s' % self.dport if self.dport != 'any' else ''
        return dport

    def _make_destination(self):
        return self.dest

    def _make_protocol(self):
        protocol = '-p %s' % self.protocol if self.protocol != 'all' else ''
        return protocol

    def is_correct(self):
        # 检查规则是否正确
        return True

    def make_rule(self):
        ''' 单条规则组成iptables支持的格式 '''
        kw = {
            'protocol': self._make_protocol(),
            'destination': self._make_destination(),
            'dport': self._make_dport(),
            'action': self.action,
        }
        return '-A OUTPUT -d {destination} {protocol} {dport} -j {action}'.format(**kw)


class Switch(models.Model):
    id = models.AutoField(primary_key=True)
    hostname = models.CharField('部署单元名', max_length=20, unique=True)
    status = models.IntegerField('状态', default=1,
            choices=[(0, 'closed'), (1, 'open')])
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    update_time = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 't_rule_switch'
        verbose_name = '控制开关'
        verbose_name_plural = verbose_name
