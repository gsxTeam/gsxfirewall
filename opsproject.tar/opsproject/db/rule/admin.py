# -*- coding: utf-8 -*-
from django.contrib import admin
from .models import Rule, Switch


class RuleAdmin(admin.ModelAdmin):
    list_display = ['hostname', 'dest', 'dport', 'protocol', 'action', 'status', 'update_time']
    readonly_fields = []
    search_fields = ['hostname', 'dest']
    list_filter = ['status', 'action']
    # list_per_page = 50


class SwitchAdmin(admin.ModelAdmin):
    list_display = ['hostname', 'status', 'update_time']
    search_fields = ['hostname']
    list_filter = ['status']
    # list_per_page = 50


admin.site.register(Rule, RuleAdmin)
admin.site.register(Switch, SwitchAdmin)
