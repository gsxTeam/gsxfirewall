#!/usr/bin/env python
# -*- coding: utf-8 -*-
''' 本脚本工作:
    * 定时拉去中控中心的配置(定时任务配置)
    * 根据配置，更新/清除防火墙策略
    * 超时失败，失败重试3次
    * 只在配置有更新时进行操作
    * 兼容py2和py3，不依赖其他第三方库
先决条件:
    * CentOS7的系统需要先执行: yum install -y iptables-services
    * 检查iptables的配置位置: /etc/sysconfig/iptables
'''
import os
import time
import json
import socket
import urllib
import httplib

# ------------------ 修改变量的地方 ------------------------
DLE_NAME = os.environ.get('DLE_NAME') or 'a'  # 尝试从环境变量获取DLE_NAME
REMOTE_HOST = '127.0.0.1'
REMOTE_IP = '127.0.0.1'
REMOTE_PORT = 8080
REMOTE_MONITOR_URI = "/api/v1/rule/list/"
RETRY_COUNT = 3  # 网络连接3次重试
socket.setdefaulttimeout(10)  # 10秒超时
DEBUG = False  # 是否在调试
# ----------------------------------------------------------


def get_local_ip():
    ''' 获取本机的IP地址 '''
    host_ip_list = [k for k in run_comm('hostname -I').split() if k]
    for ip in host_ip_list:
        if ip.startswith('100.'):
            return ip
    return '127.0.0.1'


def run_comm(line):
    print(line)
    return os.popen(line).read()


class Client(object):

    def query_iptables(self):
        ''' 通过http请求得到当前机器上的iptables配置 '''
        params = {
            'hostname': DLE_NAME,
            'formatter': 'text',
            'ip': get_local_ip(),
        }
        params = urllib.urlencode(params)
        headers = {"Host": REMOTE_HOST, "Connection": "close"}
        try_count = 1
        while try_count <= RETRY_COUNT:
            http_client = httplib.HTTPConnection(REMOTE_IP, REMOTE_PORT)
            try:
                http_client.request(method="GET", url=REMOTE_MONITOR_URI + "?" + params, headers=headers)
                response = http_client.getresponse()
                if response.status == 200:
                    return json.loads(response.read())['data']
            except Exception as e:  # retry
                # logger.error(e)
                print(str(e))
                time.sleep(0.5)
            finally:
                print('query %s:%s' % (REMOTE_IP, REMOTE_PORT))
                try_count += 1
                if http_client:
                    http_client.close()

    def need_modify(self, output):
        ''' 对比/etc/sysconfig/iptables的内容是否与output相同 '''
        old_text = run_comm('cat /etc/sysconfig/iptables')
        if old_text == output:
            return False
        # 备份规则
        run_comm('cat /etc/sysconfig/iptables > /etc/sysconfig/iptables.bak')
        return True

    def clear_iptables(self):
        ''' 删除iptables规则 '''
        run_comm('iptables -t filter -F && iptables-save > /etc/sysconfig/iptables')

    def update_iptables(self, output):
        ''' 更新iptables规则 '''
        with open('/etc/sysconfig/iptables', 'w') as f_write:
            f_write.write(output)
        run_comm('iptables-restore < /etc/sysconfig/iptables')

    def main(self):
        data = self.query_iptables()
        if not data:
            print('get nothing in query_iptables')
            return
        status = data['status']  # open / closed
        output = data['output']
        if status == 'closed':  # 清除iptables规则
            self.clear_iptables()
        elif status == 'open':  # 判断/etc/sysconfig/iptables是否有变更,有则更新
            if self.need_modify(output):
                self.update_iptables(output)
        else:
            print('get unexpected status: %s, %s' % (status, output))


if __name__ == '__main__':
    Client().main()
