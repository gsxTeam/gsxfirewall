## 概述

* 本项目为理清测试环境中的项目依赖而立项, 即限制A项目只能去访问明确的机器，不在名单中的限制访问
* 本项目分为"服务端"和"客户端agent"
* 原理: 客户端安装脚本，定时从中控中心拉取配置更新本地的iptables; 对于非预期的IP端口限制访问

## 启动项目(服务端)

安装依赖:

    sudo yum -y install mariadb
    sudo yum -y install mariadb-server
    sudo systemctl start mariadb
    sudo systemctl enable mariadb
    sudo yum -y install mysql-devel

修改mysql的账号密码和创建数据库:

    create database opsproject_db default charset utf8mb4;
    grant all privileges on opsproject_db.* to 'hongxc001'@'localhost' identified by 'password';

修改conf/config_sample.ini配置，并改名为conf/config.ini

如果部署在其他机器，需要修改opsproject/settings.py 配置中的 ALLOWED_HOSTS

安装项目依赖:

    sudo pip install -r requirements.txt
    python manage.py migrate
    python manage.py createsuperuser  # 创建超管账号并记住
    python manage.py runserver 8080

配置中控中心iptables规则, 访问网页:

    http://xx.xx.xx.xx/admin/


## 启动项目(客户端)

    yum install -y iptables-services
    systemctl start iptables
    systemctl enable iptables

修改 agent/opproj-agent.py 文件中的配置，并添加到crontab任务中:

    */1 * * * * root python agent/opsproj-agent.py 1>> /tmp/opsproj-info.log 2>> /tmp/opsproj-error.log

## 查看防火墙规则

centos6:

    cat /etc/sysconfig/iptables

centos7:

    yum install -y iptables-services
    systemctl start iptables
    systemctl enable iptables
    cat /etc/sysconfig/iptables


## 默认防火墙规则

    # sample configuration for iptables service
    # you can edit this manually or use system-config-firewall
    # please do not ask us to add additional ports/services to this default configuration
    *filter
    :INPUT ACCEPT [0:0]
    :FORWARD ACCEPT [0:0]
    :OUTPUT ACCEPT [0:0]
    -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
    -A INPUT -p icmp -j ACCEPT
    -A INPUT -i lo -j ACCEPT
    -A INPUT -p tcp -m state --state NEW -m tcp --dport 22 -j ACCEPT
    -A INPUT -j REJECT --reject-with icmp-host-prohibited
    -A FORWARD -j REJECT --reject-with icmp-host-prohibited
    COMMIT
