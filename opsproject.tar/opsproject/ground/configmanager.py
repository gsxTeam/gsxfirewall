# -*- coding: utf-8 -*-
import os
import tempfile
try:
    import ConfigParser
except ImportError:
    import configparser as ConfigParser


class ConfigManager(object):
    '''
    root_distance: count of levels between this file and project root.

    Project---src --- **.py
            |     |
            |     --- ground --- **.py
            |            |
            |            ------ <this file>
            |
            --conf --- config.ini
            |
            --log ---- info.log
                  |
                  ---- error.log

    Then root_distance is 3.
    '''

    def __init__(self, root_distance=2):
        assert root_distance > 1
        dir_pointer = os.path.dirname(os.path.abspath(__file__))
        for i in range(root_distance - 1):
            dir_pointer = os.path.dirname(dir_pointer)
        self.root = dir_pointer
        self.conf_dir = os.path.join(self.root, "conf")
        self.conf_file = os.path.join(self.conf_dir, "config.ini")
        self.config = ConfigParser.RawConfigParser()
        self.config.read(self.conf_file)
        self.log_dir = os.path.join(self.root, "log")

    def get_log_path(self, fn):
        if not fn.endswith('.log'):
            fn += '.log'
        return os.path.join(self.log_dir, fn)

    def get(self, *args, **kwargs):
        return self.config.get(*args, **kwargs)

    def getint(self, *args, **kwargs):
        return self.config.getint(*args, **kwargs)

    def getboolean(self, *args, **kwargs):
        return self.config.getboolean(*args, **kwargs)

    def getlist(self, *args, **kwargs):
        _str = self.config.get(*args, **kwargs)
        return [k.strip() for k in _str.split(',') if k.strip()]
