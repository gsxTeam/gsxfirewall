# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from ._compact import bytes2unicode, unicode_compatible

'''
错误代号说明：
*  错误代号共5位
*  第一位，表示错误层级，1表示系统级，2表示服务级
   [1xxxx] 系统级别错误
   [2xxxx] 服务级别错误
*  第二三位，表示模块级别
   [201xx] 01模块的错误，01模块具体指什么待确定
*  第四五位，表示具体错误
'''


class Code(object):
    INTERNAL_ERROR = (10000, '系统错误')

    COMMON_ERROR = (20000, '服务错误')
    PARAM_ERROR = (20001, '参数错误')

    NOT_EXIST_ERROR = (20011, '对象不存在')
    MULTIPLE_ERROR = (20012, '对象不唯一')
    ALREADY_DELETE_ERROR = (20013, '对象已经删除')

    OPERATION_TOO_FREQUENT = (20021, '操作过于频繁')
    AUTH_ERROR = (20022, '认证失败')
    FORBIDDEN_ERROR = (20023, '没有权限')

    UNKNOWN_ERROR = (99999, '未知错误')


@unicode_compatible
class GroundException(Exception):
    default = Code.COMMON_ERROR

    def __init__(self, msg=None, code_tuple=None, **kwargs):
        code_tuple = code_tuple or self.__class__.default
        assert isinstance(code_tuple, tuple)

        self.code = code_tuple[0]
        self.msg = bytes2unicode(msg or code_tuple[1])

        if kwargs.get('extra_msg'):
            self.msg = '%s: %s' % (self.msg, kwargs['extra_msg'])

        self.data = kwargs.get('data', {})

    def __str__(self):
        return self.msg


class IntenalError(GroundException):
    default = Code.INTERNAL_ERROR


class CommonError(GroundException):
    default = Code.COMMON_ERROR


class ParamError(GroundException):
    default = Code.PARAM_ERROR


class AuthError(CommonError):
    default = Code.AUTH_ERROR


class ForbiddenError(CommonError):
    default = Code.FORBIDDEN_ERROR


class NotExistError(CommonError):
    default = Code.NOT_EXIST_ERROR


class MultipleError(CommonError):
    default = Code.MULTIPLE_ERROR


class AlreadyDeleteError(CommonError):
    default = Code.ALREADY_DELETE_ERROR


class HttpMethodNotDefined(CommonError):
    def __init__(self, msg=None, code_tuple=None, **kwargs):
        super(HttpMethodNotDefined, self).__init__(msg='method not defined')
