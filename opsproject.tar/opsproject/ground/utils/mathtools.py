# -*- coding: utf-8 -*-
from decimal import Decimal


def get_growth_rate(this, that, num=2):
    ''' this相对于that的增长率 '''
    d_this = Decimal(this)
    d_that = Decimal(that)
    return round((d_this - d_that) / d_that, num) if d_that else 0


def get_rate(this, that, num=2):
    ''' 相除this/that求比率 '''
    d_this = Decimal(this)
    d_that = Decimal(that)
    return round(d_this / d_that, num) if d_that else 0


def gen_percent(args_list, num=2):
    ''' 将args_list转为一组百分比占比
    比如[1, 4, 5] => [0.1, 0.4, 0.5]
    '''
    origin_list = [Decimal(k) for k in args_list]
    sumOrigin = sum(origin_list)
    if sumOrigin == 0:
        return args_list
    ret_list = [Decimal(str(round(v/sumOrigin, num))) for v in origin_list]
    # 调整百分比的总和为1
    diff = sum(ret_list) - Decimal(1)
    maxValue = max(ret_list)
    ret_list[ret_list.index(maxValue)] = maxValue - diff
    return [round(v, num) for v in ret_list]


def to_percentage(this):
    ''' 将小数转化为百分比表示的字符串 '''
    ret = '%s' % (this * 100)
    if '.' in ret:
        ret = ret.rstrip('0').rstrip('.')
    return ret + '%'
