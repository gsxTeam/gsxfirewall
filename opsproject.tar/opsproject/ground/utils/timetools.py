# -*- coding: utf-8 -*-
import datetime
import calendar


def today():
    return datetime.datetime.now().date()


def yesterday():
    return today() - datetime.timedelta(days=1)


def datetime_to_ts(dt):
    return calendar.timegm(dt.utctimetuple())


def ts_to_datetime(timestamp):
    return datetime.datetime.utcfromtimestamp(timestamp)


def str_to_date(date_str, pattern='%Y-%m-%d'):
    return datetime.datetime.strptime(date_str, pattern).date()


def str_to_datetime(datetime_str, pattern='%Y-%m-%d %H:%M:%S'):
    return datetime.datetime.strptime(datetime_str, pattern)


def date_to_str(dateobj, pattern='%Y-%m-%d'):
    return dateobj.strftime(pattern)


def datetime_to_str(dtobj, pattern='%Y-%m-%d %H:%M:%S'):
    return dtobj.strftime(pattern)


class TimeTools(object):

    @staticmethod
    def to_hour(dt):
        return dt.replace(minute=0, second=0, microsecond=0).time()

    @staticmethod
    def to_day(dt):
        if isinstance(dt, datetime.datetime):
            return dt.date()
        else:
            return dt

    @staticmethod
    def to_week(dt):
        then = TimeTools.to_day(dt)
        return then - datetime.timedelta(days=then.weekday())

    @staticmethod
    def to_week_lastday(dt):
        return TimeTools.to_week_range(dt)[1]

    @staticmethod
    def to_week_range(dt):
        start = TimeTools.to_week(dt)
        return start, start + datetime.timedelta(days=6)

    @staticmethod
    def to_month(dt):
        return TimeTools.to_day(dt).replace(day=1)

    @staticmethod
    def to_month_lastday(dt):
        firstday = TimeTools.to_month(dt)
        firstnext = TimeTools.to_month(firstday + datetime.timedelta(days=32))
        return firstnext - datetime.timedelta(days=1)

    @staticmethod
    def to_month_range(dt):
        start = TimeTools.to_month(dt)
        end = TimeTools.to_month_lastday(dt)
        return start, end
