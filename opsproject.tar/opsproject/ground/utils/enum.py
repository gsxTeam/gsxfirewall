# -*- coding: utf-8 -*-


class Enum(object):
    '''
    >>> Sex = Enum(((1, "FEMALE", "female"),
    ...             (2, "MALE", "male")))
    ...
    >>> Sex.FEMALE
    1
    >>> tuple(Sex.choice_tuples())
    ((1, 'female'), (2, 'male'))
    >>> tuple(Sex.available_options())
    (1, 2)
    '''

    def __init__(cls, config):
        cls.config = config
        for item in config:
            setattr(cls, item[1], item[0])

    def choice_tuples(cls):
        return ((item[0], item[2]) for item in cls.config)

    def to_name(cls, key):
        return dict(cls.choice_tuples()).get(key, u'Unknown')

    def available_options(cls):
        return (item[0] for item in cls.config)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
