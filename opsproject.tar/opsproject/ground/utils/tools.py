# -*- coding: utf-8 -*-
import decimal
import datetime
import json
import sys
from .timetools import datetime_to_str, date_to_str

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

if PY2:  # pragma: no cover
    unicode_type = unicode
else:  # pragma: no cover
    unicode_type = str


def enum(*sequential, **named):
    enums = dict(zip(sequential, range(len(sequential))), **named)
    return type('Enum', (), enums)


def merge_list(first, second):
    return list(set(first) | set(second))


def diff_list(first, second):
    return list(set(first) - set(second))


def inter_list(first, second):
    return list(set(first) & set(second))


def contains_list(big, small):
    assert isinstance(big, (tuple, list, set, frozenset))
    if isinstance(small, (tuple, list, set, frozenset)):
        for item in small:
            if item not in big:
                return False
        return True
    return small in big


def bytes2unicode(_str, decoding='utf-8'):
    if isinstance(_str, unicode_type):
        return _str
    return _str.decode(decoding, 'replace')


def unicode2bytes(_str, encoding='utf-8'):
    if isinstance(_str, unicode_type):
        return _str.encode(encoding, 'replace')
    return _str


def handle_object_for_json(obj):
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    elif isinstance(obj, int):
        return obj
    elif isinstance(obj, datetime.datetime):
        return datetime_to_str(obj)
    elif isinstance(obj, datetime.date):
        return date_to_str(obj)
    elif isinstance(obj, datetime.time):
        return str(obj)
    elif hasattr(obj, 'to_dict'):
        return obj.to_dict()
    else:
        return obj


def model2dict(model, keep_list=None):
    ret = {}
    if isinstance(model, dict):
        ret.update({k: handle_object_for_json(v) for k, v in model.iteritems()})
    else:
        ret = {k: handle_object_for_json(v) for k, v in
               model.__dict__.iteritems() if not k.startswith('_')}
    if keep_list:
        return {k: v for k, v in ret.iteritems() if k in keep_list}
    return ret


def query2dictlist(queryset, keep_list=None):
    ret_list = []
    for model in queryset:
        ret_list.append(model2dict(model, keep_list=keep_list))
    return ret_list


def encode_json(data):
    return json.dumps(data, default=handle_object_for_json)


def is_ascii(s):
    return all(ord(c) < 128 for c in s)
