# -*- coding: utf-8 -*-
import functools
import re
from .exceptions import ParamError
from .base import BaseAction
from .utils.timetools import str_to_date, str_to_datetime

EMAIL_PROG = re.compile(r'\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$')


class ParamSetError(ParamError):
    '''ParamSetError'''
    def __init__(self, errors):
        # errors :((key, error),(key, error),)
        # key is str, error is ParamError
        super(ParamError, self).__init__()
        if isinstance(errors, (list, tuple)):
            self.errors = errors
        else:
            self.errors = [errors, ]
        self.msg = '\n'.join(['%r: %s' % (key, str(e)) for key, e in self.errors])


class Field(object):
    def __init__(self, description=None, key=None, required=None, length=None,
                 choices=None, default=None, max_value=None, min_value=None,
                 group=None, in_route=None, strip=True):
        self.description = description
        self.key = key
        self.required = required
        self.in_route = in_route

        self.strip = strip  # 取消开头空格和结尾空格
        self.choices = choices  # 值必须在选择范围内
        self.default = default

        self.length = length  # ??
        self.max_value = max_value
        self.min_value = min_value
        # TODO:分组功能暂时不支持
        self.group = group

        if self.in_route:
            self.required = True
        if length:
            if isinstance(length, (int, float)):
                assert length > 0
                self.min_length = 0
                self.max_length = length
            elif isinstance(length, (tuple, list)):
                assert len(length) == 2 and length[0] > 0 and length[1] >= length[0]
                self.min_length = length[0]
                self.max_length = length[1]
        if choices:
            assert isinstance(choices, (list, tuple, set, frozenset))
        if max_value and min_value:
            assert max_value >= min_value

    def raise_exc(self, msg=None):
        raise ParamError(msg=msg)

    def _validate_length(self, value):
        min_length = self.min_length
        max_length = self.max_length
        value_len = len(value)
        if value_len > max_length:
            self.raise_exc(msg='more than %r in length' % max_length)
        if value_len < min_length:
            self.raise_exc(msg='no more than %r in length' % min_length)
        return value

    def _validate_choices(self, value):
        choices = self.choices
        if value not in choices:
            self.raise_exc(msg='%r不在%r范围内' % (value, choices))
        return value

    def _validate_type(self, value):
        '''override if needed'''
        return value

    def _validate_min_value(self, value):
        min_value = self.min_value
        if value < min_value:
            self.raise_exc(msg='value should larger than %r, but %r' % (min_value, value))
        return value

    def _validate_max_value(self, value):
        max_value = self.max_value
        if value > max_value:
            self.raise_exc(msg='value should smaller than %r, but %r' % (max_value, value))
        return value

    def validate(self, value):
        # validate 必须放在第一位，因为网络传输数据是unicode，int类型需要转化
        value = self._validate_type(value)
        if self.length:
            self._validate_length(value)
        if self.choices:
            self._validate_choices(value)
        if self.min_value:
            self._validate_min_value(value)
        if self.max_value:
            self._validate_max_value(value)
        return value

    def is_required(self):
        return self.required

    # owner.data 依赖ParamSet.data
    def __get__(self, owner, cls):
        return owner.data.get(self.key, self.default)

    def __set__(self, owner, value):
        raise AttributeError('Cannot set value to a field')


class IntegerField(Field):

    def _validate_type(self, value):
        try:
            return int(value)
        except (ValueError, TypeError):
            self.raise_exc(msg='%r不是整数' % value)


class FloatField(Field):
    def _validate_type(self, value):
        try:
            return float(value)
        except (ValueError, TypeError):
            self.raise_exc(msg='%r不是浮点数' % value)


class StringField(Field):
    def _validate_type(self, value):
        try:
            if self.strip:
                value = value.strip()
            return value
        except (ValueError, TypeError):
            self.raise_exc(msg='cannot convent %r into str' % value)


class ListField(Field):
    def _validate_type(self, value):
        try:
            return [v.strip() for v in value.split(",")]
        except (ValueError, TypeError):
            self.raise_exc(msg='cannot convent %r into list' % value)


class EmailField(Field):
    def _validate_type(self, value):
        try:
            value = value.strip()
            if not EMAIL_PROG.match(value):
                self.raise_exc(msg='邮箱格式不正确')
            return value
        except (ValueError, TypeError):
            self.raise_exc(msg='cannot convent %r into email' % value)


class DateField(Field):
    def _validate_type(self, value):
        try:
            value = value.strip()
            # android may post '2014-00xx-xx' or '2014-xx-00xx' to server
            # do something to avoid this
            three = value.split('-')
            if len(three) == 3 and (len(three[1]) != 2 or len(three[2]) != 2):
                three[1] = three[1].replace('00', '')
                three[2] = three[2].replace('00', '')
                value = '-'.join(three)
            return str_to_date(value)
        except (ValueError, TypeError):
            self.raise_exc(msg='%r日期格式错误' % value)


class DateTimeField(Field):
    def _validate_type(self, value):
        try:
            value = value.strip()
            return str_to_datetime(value)
        except (ValueError, TypeError):
            self.raise_exc(msg='%r时间格式错误' % value)


class ParamSetMeta(type):
    def __new__(cls, name, bases, attrs):
        fields = {}
        for k, f in attrs.items():
            if isinstance(f, Field):
                f.name = k
                if not f.key:
                    f.key = k
                fields[k] = f
        attrs['_fields'] = fields
        return type.__new__(cls, name, bases, attrs)


def _unicode(unicode_value):
    return unicode_value


class ParamSet(object):
    __metaclass__ = ParamSetMeta  # python 2
    __datatype__ = 'json'

    def __init__(self, *args, **kwargs):
        # examples: 解释一下data _raw_data _request_data的编码问题
        # 假设request的数据是 first=1&second=test
        # _request_data = {'first': ['1',], 'second': 'test'}
        # _raw_data在_request_data基础上增加Field.default
        # data = {'first': 1, 'second': 'test'}
        self.errors = []
        self.data = {}  # 将验证的数据转为特定格式，比如int类型
        self._raw_data = {}  # 需要验证的数据，包括default
        self._request_data = {}  # 请求过来的数据

        for k in kwargs:
            if isinstance(kwargs[k], (list, tuple)):
                # django将get方法的query /?data=1 编码成 data=['1',]
                if len(kwargs.get(k)) == 1:
                    self._request_data[k] = _unicode(kwargs.get(k)[0])
                else:
                    self._request_data[k] = map(_unicode, kwargs[k])
            else:
                self._request_data[k] = _unicode(kwargs[k])

        self._raw_data.update(self._request_data)
        for name, field in self.__class__._fields.items():
            if field.default is not None and name not in self._request_data:
                self._raw_data.update({name: field.default})
        self.validate()

    def validate(self):
        for name, field in self.__class__._fields.items():
            key = field.key
            if key in self._raw_data:
                value = self._raw_data[key]
                try:
                    value = field.validate(value)
                    # 参数名如果是type，length等已经定义的函数名就会抛出异常
                    # func_name = 'validate_' + key
                    # if hasattr(self, func_name):
                    #     value = getattr(self, func_name)(value)
                    #     # Don't forget to return value in validate_key
                    #     assert value is not None
                    self.data[key] = value
                except ParamError as e:
                    self.errors.append((key, e))
            else:
                if field.is_required():
                    try:
                        field.raise_exc(msg='%r is required' % key)
                    except ParamError as e:
                        self.errors.append((key, e))

    @classmethod
    def validate_required(cls, method):
        @functools.wraps(method)
        def wrapper(action, request):
            assert isinstance(action, BaseAction)
            arguments = action.get_request_data_dict()
            paramset = cls(**arguments)

            if paramset.errors:
                raise ParamSetError(paramset.errors)
            action.params = paramset

            return method(action, request)
        return wrapper


def define_params(kwargs):
    # kwargs中的key名不能与原ParamSet的字段重复
    forbid_names = dir(ParamSet)
    for k in kwargs:
        assert str(k) not in forbid_names
    paramset = type('AutoCreatedParamSet', (ParamSet,), kwargs)
    return paramset.validate_required
