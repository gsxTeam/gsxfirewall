# -*- coding: utf-8 -*-
import sys
import logging
import traceback

error_log = logging.getLogger('error_log')
info_log = logging.getLogger('info_log')


class LogExceptionMiddleware(object):

    def process_exception(self, request, exception):
        error_log.error(request)
        # body = getattr('request', 'body', None)
        # if body:
        #     error_log.error(body)
        trace_info = '\n'.join(traceback.format_exception(*sys.exc_info()))
        error_log.error(trace_info)
