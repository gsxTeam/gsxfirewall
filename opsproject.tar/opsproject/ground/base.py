# -*- coding: utf-8 -*-
import json
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse, JsonResponse
from django.views.generic.base import View
from .exceptions import (
    GroundException, ForbiddenError, HttpMethodNotDefined,
    Code, AuthError
)

OK_MESSAGE = 'ok'
OK_CODE = 0


class BaseAction(View):
    def __init__(self, *args, **kwargs):
        super(BaseAction, self).__init__(*args, **kwargs)
        self._status_code = 200
        self._request_data_dict = {}
        self._request_method = None
        self._request = None
        self._response_data_dict = {
            'msg': OK_MESSAGE,
            'code': OK_CODE,
            'data': {},
        }

    def get_request_data_dict(self):
        return self._request_data_dict

    @csrf_exempt
    def dispatch(self, request, *args, **kwargs):
        request_method = request.method.lower()
        self._request_method = request_method
        self._request = request
        processor = getattr(self, request_method, None)
        if not processor:
            raise HttpMethodNotDefined(extra_msg=request_method)
        try:
            return self.build_response(processor, request, *args, **kwargs)
        except GroundException as e:
            return self.build_exc(e)

    def _fetch_body_data(self, request, *args, **kwargs):
        json_data = request.body
        if not json_data:
            return {}
        try:
            return json.loads(json_data)
        except ValueError:
            return {}

    def _fetch_get_data(self, request, *args, **kwargs):
        params_dict = {k: v for k, v in request.GET.items()}
        for k, v in params_dict.items():
            if isinstance(v, list) and len(v) == 1:
                params_dict[k] = v[0]
        return params_dict or {}

    def _fetch_post_data(self, request, *args, **kwargs):
        params_dict = {k: v for k, v in request.POST.items()}
        for k, v in params_dict.items():
            if isinstance(v, list) and len(v) == 1:
                params_dict[k] = v[0]
        return params_dict or {}

    def format_request(self, request, *args, **kwargs):
        self._request_data_dict.update(self._fetch_body_data(request, *args, **kwargs))
        self._request_data_dict.update(self._fetch_get_data(request, *args, **kwargs))
        self._request_data_dict.update(self._fetch_post_data(request, *args, **kwargs))
        self._request_data_dict.update(kwargs)

    def build_response(self, processor, request, *args, **kwargs):
        self.format_request(request, *args, **kwargs)

        self.pre_processor(request, *args, **kwargs)
        result = processor(request, *args, **kwargs)
        self.post_processor(request, *args, **kwargs)
        # 兼容原来的json数据返回
        if result is None:
            return self._render_response()
        # 返回HttpResponse等网页形式
        else:
            return result

    def pre_processor(self, request, *args, **kwargs):
        pass

    def post_processor(self, request, *args, **kwargs):
        pass

    def _render_response(self):
        callback = self.get_request_data_dict().get('_jsonp', '')
        response_data = self._response_data_dict
        if callback:
            jsonp = '%s(%s)' % (callback, json.dumps(response_data))
            response = HttpResponse(jsonp, status=self._status_code)
        else:
            response = JsonResponse(response_data, status=self._status_code)
        if self._status_code == 401:
            response['WWW-Authenticate'] = 'Basic realm="USER LOGIN"'
        return response

    def set_status(self, code):
        assert isinstance(code, int) and code >= 100 and code < 600
        self._status_code = code

    def write_data(self, data_dict):
        self._response_data_dict['data'] = data_dict or {}

    def build_exc(self, e):
        self.pre_handler_error(e)
        self._handler_error(e)
        self.post_handler_error(e)
        return self._render_response()

    def pre_handler_error(self, e):
        pass

    def post_handler_error(self, e):
        pass

    def _handler_error(self, e):
        if isinstance(e, AuthError):
            self.set_status(401)
        elif isinstance(e, ForbiddenError):
            self.set_status(403)
        else:
            self.set_status(400)
        self._response_data_dict.update({
            'msg': str(e),
            'code': getattr(e, 'code', Code.UNKNOWN_ERROR[0]),
        })
