# -*- coding: utf-8 -*-
from opsproject.settings import config_manager
from db.rule.models import Rule

CENTER_IP = config_manager.config.get("center", "host")
CENTER_PORT = config_manager.config.getint("center", "port")


class RuleHelper(object):

    @staticmethod
    def before_list():
        rule_list = [
            '# sample configuration for iptables service',
            '# you can edit this manually or use system-config-firewall',
            '# please do not ask us to add additional ports/services to this default configuration',
            '*filter',
            ':INPUT ACCEPT [0:0]',
            ':FORWARD ACCEPT [0:0]',
            ':OUTPUT ACCEPT [0:0]',

            # '-A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT',
            # '-A INPUT -p icmp -j ACCEPT',
            # '-A INPUT -i lo -j ACCEPT',
            # '-A INPUT -p tcp -m state --state NEW -m tcp --dport 22 -j ACCEPT',
            # '-A INPUT -j REJECT --reject-with icmp-host-prohibited',
            # '-A FORWARD -j REJECT --reject-with icmp-host-prohibited',

            '-A OUTPUT -m state --state RELATED,ESTABLISHED -j ACCEPT',  # 响应请求
            '-A OUTPUT -p icmp -j ACCEPT',  # icmp请求
            '-A OUTPUT -o lo -j ACCEPT',  # 本地网卡
            '-A OUTPUT -d 10.200.0.0/16 -j ACCEPT',  # 办公网出
            '-A OUTPUT -d 100.65.247.0/24 -j ACCEPT',  # VPN出
            '-A OUTPUT -d %s -p tcp --dport %s -j ACCEPT' % (CENTER_IP, CENTER_PORT),  # 服务器中心
        ]
        return rule_list

    @staticmethod
    def middle_list(hostname):
        rule_list = Rule.objects.filter(hostname=hostname, status=1)
        rule_list = [r.make_rule() for r in rule_list]
        return rule_list

    @staticmethod
    def after_list():
        rule_list = [
            '-A OUTPUT -j REJECT --reject-with icmp-admin-prohibited',
            'COMMIT',
        ]
        return rule_list

    @staticmethod
    def make_rule(hostname, formatter='text'):
        ''' hostname: 主机名，查询指定主机名上的规则
        formatter: 输出格式, 可选list, text
        '''
        cls = RuleHelper
        rule_list = cls.before_list() + cls.middle_list(hostname) + cls.after_list()
        if formatter == 'list':
            return rule_list
        else:
            return '\n'.join(rule_list) + '\n'
