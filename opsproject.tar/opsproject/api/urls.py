# -*- coding: utf-8 -*-
from django.conf.urls import include, url


urlpatterns = (
    url(r"^rule/", include('api.ruleapi')),
)
