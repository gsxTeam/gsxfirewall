# -*- coding: utf-8 -*-
from django.conf.urls import url
from common.action import JsonAction, user_required
from ground.params import define_params, StringField
from ground.exceptions import CommonError
from service.rule import RuleHelper
from db.rule.models import Switch


class RuleListAction(JsonAction):

    @user_required
    @define_params({
        'formatter': StringField(default='list', choices=['list', 'text']),
        'hostname': StringField(required=True),
        'ip': StringField(),
    })
    def get(self, request):
        hostname = self.params.hostname
        formatter = self.params.formatter
        switch = Switch.objects.filter(hostname=hostname).first()

        status = {1: 'open', 0: 'closed'}[switch.status] if switch else 'closed'
        output = None
        if status == 'open':
            output = RuleHelper.make_rule(hostname, formatter=formatter)
        self.write_data({'output': output, 'status': status})


class SecondAction(JsonAction):

    @user_required
    def get(self, request):
        raise CommonError(msg='something error.')


urlpatterns = (
    url(r'^list/?$', RuleListAction.as_view()),
)
